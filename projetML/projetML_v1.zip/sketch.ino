#include <DHT.h>
#define DHTPIN 4
#define DHTTYPE DHT22
DHT dht(DHTPIN, DHTTYPE);

#define POT_PIN 34   // pluie
#define LDR_PIN 35   // nuages
#define BTN_JAUNE 19 // Voie 1
#define BTN_VERT 5   // Voie 2
#define PIR_PIN 18   // Voie 3 / detection auto

int trafficCount = 0;
unsigned long lastPublish = 0;

void setup() {
  Serial.begin(115200);
  dht.begin();
  pinMode(BTN_JAUNE, INPUT_PULLUP);
  pinMode(BTN_VERT, INPUT_PULLUP);
  pinMode(PIR_PIN, INPUT);
  Serial.println("=== Station IoT Trafic I-94 V1 READY ===");
}

void loop() {
  // Comptage
  if (digitalRead(BTN_JAUNE) == LOW) { trafficCount++; Serial.println("Voiture Voie Jaune"); delay(200); }
  if (digitalRead(BTN_VERT) == LOW) { trafficCount++; Serial.println("Voiture Voie Verte"); delay(200); }
  if (digitalRead(PIR_PIN) == HIGH) { trafficCount++; Serial.println("Voiture PIR"); delay(500); }

  // Publication toutes les 5 sec = 1 "heure" simulée
  if (millis() - lastPublish > 5000) {
    lastPublish = millis();
    float tempC = dht.readTemperature();
    if (isnan(tempC)) tempC = 20.0;
    int rain = map(analogRead(POT_PIN), 0, 4095, 0, 15);
    int clouds = map(analogRead(LDR_PIN), 0, 4095, 0, 100);
    int volume = trafficCount * 12; // extrapolation

    // Format IDENTIQUE à ton CSV
    Serial.printf("JSON_MQTT: {\"temp\":%.2f,\"rain_1h\":%d,\"clouds_all\":%d,\"traffic_volume\":%d}\n",
                  tempC + 273.15, rain, clouds, volume);
    
    trafficCount = 0;
  }
}